# BIOMA — Cozinha de sabores & memórias doces

Landing page da BIOMA: pratos executivos e sobremesas artesanais, com foco em conversão para delivery.

## Estrutura do projeto

```
.
├── index.html              # página completa (HTML + CSS + JS em um único arquivo)
└── images/
    ├── rodrigo.jpg          # foto do chef Rodrigo Martins
    ├── laudja.png           # foto da confeiteira Laudja Pessoa
    └── sobremesas/          # fotos dos produtos de confeitaria
```

## Como editar

- **Produtos (pratos e sobremesas)**: abra `index.html`, procure por `const PRODUCTS = {` perto do fim do arquivo. Cada produto é um objeto com `name`, `description`, `price`, `image`, `deliveryLink`, `available` e `featured`. Copie um item existente para adicionar um novo.
- **Links**: procure e substitua `DELIVERY_LINK_PRATOS`, `DELIVERY_LINK_SOBREMESAS`, `WHATSAPP_LINK` e `INSTAGRAM_LINK` pelos links reais.
- **Textos pendentes**: qualquer coisa entre colchetes, como `[ADICIONAR INFORMAÇÃO]` ou `[CONFIRMAR SABOR]`, ainda precisa ser preenchida.
- **Fotos**: adicione novos arquivos na pasta `images/` e referencie o caminho relativo no campo `image` do produto (ex: `images/sobremesas/novo-doce.jpg`).

## Como publicar (GitHub Pages)

1. Crie um repositório no GitHub e suba este projeto (veja o passo a passo que o Claude te enviou no chat).
2. No repositório, vá em **Settings → Pages**.
3. Em **Source**, selecione a branch `main` e a pasta `/root` (ou `/(root)`).
4. Salve. Em alguns minutos o site estará disponível em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

## Rodando localmente

Não precisa de servidor: basta abrir `index.html` diretamente no navegador. As fontes (Google Fonts) exigem internet; o restante funciona offline.
